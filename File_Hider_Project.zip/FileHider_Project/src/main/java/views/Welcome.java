package views;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;

import dao.UserDAO;
import model.User;
import service.GenerateOTP;
import service.SendOTPService;
import service.UserService;

public class Welcome {
    public void welcomeScreen() {
    	// Read data from keyboard
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Wlcome to the app");
        System.out.println("Press 1 to login");
        System.out.println("Press 2 to signup");
        System.out.println("Press 0 to exit");
        int choice = 0; // user choise
        try {
            choice = Integer.parseInt(br.readLine()); // parse the data to Integer
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        switch (choice) {
            case 1 -> login();
            case 2 -> signUp();
            case 0 -> System.exit(0);
        }
    }
    
    private void login() { // call login by user
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter email"); // enters email for logging in
        String email = sc.nextLine();
        try {
            if(UserDAO.isExists(email)) { // checks if user exist if exist send otp
                String genOTP = GenerateOTP.getOTP(); // Otp sends
                SendOTPService.sendOTP(email, genOTP);
                System.out.println("Enter the otp"); 
                String otp = sc.nextLine(); // validate otp
                if(otp.equals(genOTP)) {
                   new UserView(email).home(); // if otp is valid create userview object and call home method

                } else {
                    System.out.println("Wrong OTP"); // if wrong otp sends message
                }
            } 
            else {
                System.out.println("User not found"); // or user not found
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }
    
    // get the data and store it in database
    private void signUp() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name");
        String name = sc.nextLine();
        System.out.println("Enter email");
        String email = sc.nextLine();
        String genOTP = GenerateOTP.getOTP();
        SendOTPService.sendOTP(email, genOTP); // sends otp on the email to sign up
        System.out.println("Enter the otp");
        String otp = sc.nextLine();
        if(otp.equals(genOTP)) { // if otp is valid
            User user = new User(name, email); // create new user
            int response = UserService.saveUser(user); // if added it will be 1 and print case 1
            switch (response) {
                case 0 -> System.out.println("User registered");
                case 1 -> System.out.println("User already exists");
            }
        } else {
            System.out.println("Wrong OTP");
        }

    }
}
