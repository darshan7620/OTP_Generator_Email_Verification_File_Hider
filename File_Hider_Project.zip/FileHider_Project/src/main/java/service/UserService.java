package service;

import dao.UserDAO;
import model.User;

import java.sql.SQLException;

public class UserService {
	// checks user email exist or not if and return 0 or 1
    public static Integer saveUser(User user){
        try {
            if(UserDAO.isExists(user.getEmail())) { //user exist return 0
                return 0;
            } else {
                return UserDAO.saveUser(user); // it will return the number if user saved
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
