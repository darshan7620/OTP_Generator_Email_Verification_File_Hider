package dao;
// DAO --> DATA AUTHENTICATION OPERATIONs
import db.MyConnection;
import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
	// check if the user exists or not, if exist return true or return false
    public static boolean isExists(String email) throws SQLException {
        Connection connection = MyConnection.getConnection();
        PreparedStatement ps = connection.prepareStatement("select email from userss");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String e = rs.getString(1);
            if (e.equals(email)) // if exist return true
                return true;
        }
        return false; // if not exist return false
    }
    
    // add new user to the database
    public static int saveUser(User user) throws SQLException {
        Connection connection = MyConnection.getConnection();
        PreparedStatement ps =connection.prepareStatement("insert into userss values(s1.nextval, ?, ?)");
        ps.setString(1, user.getName());
        ps.setString(2, user.getEmail());
        return ps.executeUpdate(); // here it will return the value 1
    }
}
