import views.Welcome;

// Landing page
public class Main {
    public static void main(String[] args) {
        Welcome w =new Welcome();
        do {
            w.welcomeScreen();
        } while (true); // runs the method when task is over
    }
}
